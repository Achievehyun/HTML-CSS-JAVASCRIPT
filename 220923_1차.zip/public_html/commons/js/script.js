$(document).ready(function() {
	window.asd = $('.SlectBox').SumoSelect({
		csvDispCount: 3,
		selectAll: true,
		captionFormatAllSelected: "Yeah, OK, so everything."
	});
	window.selAll = $('.SelAll').SumoSelect({
		okCancelInMulti: false,
		selectAll: true
	});


	$('.SlectBox').on('sumo:opened', function(o) {
		console.log("dropdown opened", o)
	});
	$(".menu").on("click", function() {
		$(".gnbwrap_wrap").addClass("on");
	});
	$(".gnbwrap .btn_close").on("click", function() {
		$(".gnbwrap_wrap").removeClass("on");
	});

	var hidWidth;
	var scrollBarWidths = 50;
	if ($('.nano') >= 1) {
		$('.nano').nanoScroller();
	}


	//왼쪽 메뉴
	$('.sidebar-toggle').click(function() {
		$('html').toggleClass('sidebar-left-collapsed');
		if ($('html').hasClass('sidebar-left-collapsed')) {
			$('.nav-parent').removeClass("active");
			$('.nav-parent').removeClass("nav-expanded");
		}
	});
	$(".nav-main").on("mouseover", function() {
		$('html').removeClass('sidebar-left-collapsed');
	})
	$(".sidebar-left").on("mouseleave", function() {
		$('html').addClass('sidebar-left-collapsed');
	})

	var $items = $('.nav-main li.nav-parent');

	function expand(li) {
		li.children('ul.nav-children').slideDown('fast', function() {
			li.addClass('nav-expanded');
			li.addClass('active');
			$(this).css('display', '');
			ensureVisible(li);
		});
	}

	function collapse(li) {
		li.children('ul.nav-children').slideUp('fast', function() {
			$(this).css('display', '');
			li.removeClass('nav-expanded');
			li.removeClass('active');
		});
	}

	function ensureVisible(li) {
		var scroller = li.offsetParent();
		if (!scroller.get(0)) {
			return false;
		}
		var top = li.position().top;
		if (top < 0) {
			scroller.animate({
				scrollTop: scroller.scrollTop() + top
			}, 'fast');
		}
	}


	$items.find('> a').on('click', function() {
		if ($("html").hasClass("sidebar-left-collapsed") === false) {
			var prev = $(this).closest('ul.nav').find('> li.nav-expanded'),
				next = $(this).closest('li');
			if (prev.get(0) !== next.get(0)) {
				collapse(prev);
				expand(next);
			} else {
				collapse(prev);
			}
		};
	});

	/* 탭 스크립트 */
	$(".tab_ul > li").on("click", function() {
		$(this).siblings().removeClass('on');
		$(this).addClass('on');
		l = $(this).index();
		$(this).parent().next('.tab_con').children('div').hide();
		$(this).parent().next('.tab_con').children('div:eq('+ l + ')').show();
	});
});

function popupclose(popup) {
	$('#'+popup).hide();
}

function popupopen(popup) {
	$('#'+popup).show();
}

function chartpopupclose() {
	$("#menuDivView2").hide();
}